<?php include_once "../includes/initialize.php"; ?>
<?php
  $groups = Group::find_all();
  $alert_type = 1;

  if(isset($_POST["submit"])) {

    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $group_id = $_POST['group'];

    $new_customer = Customer::make($first_name, $middle_name, $last_name,  $email, $group_id);

    if($new_customer && $new_customer->save()) {
      $session->message("Customer record saved.");
      redirect_to("customers.php");

    } else {
      // Failed
      $message = "There was an error that prevented the customer record from being saved.";
      $alert_type = 4;
    }

  } else {
    $first_name = $middle_name = $last_name = $email = $group_id = "";
  }
?>
<?php
  include_layout_template("admin_header.php","Customers");
  include_layout_template("admin_sidebar.php");
?>
  <div class="main">

    <h1>Customer Form</h1>

    <div class="col-lg-6">
      <?php echo output_message($message, $alert_type); ?>
      <form action="" method="post" class="form-horizontal">

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">First Name: </label>
          <div class="col-md-8">
            <input type="text" name="first_name" value="<?php echo $first_name ?>" class="form-control input-sm" required>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Middle Name: </label>
          <div class="col-md-8">
            <input type="text" name="middle_name" value="<?php echo $middle_name ?>" class="form-control input-sm">
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Last Name: </label>
          <div class="col-md-8">
            <input type="text" name="last_name" value="<?php echo $last_name ?>" class="form-control input-sm" required>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Email Address: </label>
          <div class="col-md-8">
            <input type="text" name="email" value="<?php echo $email ?>" class="form-control input-sm" required>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Customer Group: </label>
          <div class="col-md-5">
            <select name="group" class="form-control input-sm">
              <option value="">--Select--</option>
              <?php
                foreach($groups AS $group) {
                  echo "<option value=\"{$group->id}\"";
                  if($group_id == $group->id) { echo " selected"; }
                  echo ">{$group->group_name}</option>";
                }
              ?>
            </select>
          </div>
        </div>

        <div class="form-group">
          <div class="col-md-4"></div>
          <div class="col-md-8">
            <input type="submit" name="submit" value="Submit" class="btn btn-primary btn-sm">
          </div>
        </div>
      </form>

    </div>

    <div class="col-lg-6">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>S/N</th>
            <th>Name</th>
            <th>Email Address</th>
            <th>Group</th>
          </tr>
        </thead>
        <tbody>
        <?php
          $customers = Customer::find_all();
          $count = 1;
          foreach($customers AS $customer) {
            $group = Group::find_by_id($customer->group_id);
            echo "<tr>
                    <td>{$count}</td>
                    <td>{$customer->full_name()}</td>
                    <td>{$customer->email}</td>
                    <td>{$group->group_name}</td>
                  </tr>";
            $count++;
          }
        ?>
        </tbody>
      </table>
    </div>





  </div>

<?php include_layout_template("footer.php"); ?>