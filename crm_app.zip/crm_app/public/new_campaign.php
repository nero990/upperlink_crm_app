<?php include_once "../includes/initialize.php"; ?>
<?php

  if(isset($_POST["submit"])) {
    $title = $_POST['title'];
    $body = $_POST['body'];
    $scheduled_at = $_POST['scheduled_at'];
    !empty($_POST['groups']) ? $groups = $_POST['groups'] : $groups = "";

    $new_campaign = Campaign::make($title, $body, $scheduled_at, $groups);

    if($new_campaign && $new_campaign->save()) {
      $session->message("New campaign Created");
      redirect_to("campaigns.php");
    } else {
      $message = "There was a problem creating new campaign";
      $alert_type = 4;
    }
  }  else {
    $title = $body = $scheduled_at = "";
  }
?>
<?php
  include_layout_template("admin_header.php","Customers");
  include_layout_template("admin_sidebar.php");
?>
  <div class="main">

    <h1>Create a New Campaign</h1>

    <div class="col-lg-8">
      <?php echo output_message($message, $alert_type); ?>
      <form action="" method="post" class="form-horizontal">

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Campaign Title: </label>
          <div class="col-md-8">
            <input type="text" name="title" value="<?php echo $title; ?>" placeholder="Campaign title" class="form-control input-sm" required>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Campaign Message: </label>
          <div class="col-md-8">
            <textarea rows="10" name="body" class="form-control input-sm" placeholder="Campaign Message"><?php echo $body; ?></textarea>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Scheduled At: </label>
          <div class="col-md-8">
            <input type="date" name="scheduled_at" value="<?php echo $scheduled_at ?>" class="form-control input-sm" placeholder="YYYY-MM-DD" required>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Target Groups: </label>
          <div class="col-md-5">
            <select name="groups[]" class="form-control input-sm" multiple>
              <option value="">--Select--</option>
              <?php
                $groups = Group::find_all();
                foreach($groups AS $group) {
                  echo "<option value=\"{$group->id}\"";
                  echo ">{$group->group_name}</option>";
                }
              ?>
            </select>
          </div>
        </div>

        <div class="form-group">
          <div class="col-md-4"></div>
          <div class="col-md-8">
            <input type="submit" name="submit" value="Create Campaign" class="btn btn-primary btn-sm">
          </div>
        </div>
      </form>

    </div>


    <div class="clearfix"></div>

  </div>

<?php include_layout_template("footer.php"); ?>