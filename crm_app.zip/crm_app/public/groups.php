<?php include_once "../includes/initialize.php"; ?>
<?php
  $alert_type = 1;

  if(isset($_POST["submit"])) {
    $group_name = $_POST['group_name'];

    $new_group = new Group();
    $new_group->group_name = $group_name;

    if($new_group && $new_group->save()) {
      $session->message("New Group created.");
      redirect_to("groups.php");

    } else {
      // Failed
      $message = "There was an error that prevented the new group from being saved.";
      $alert_type = 4;
    }
  } else {
    $group_name = "";
  }
?>
<?php
  include_layout_template("admin_header.php","Customers");
  include_layout_template("admin_sidebar.php");
?>
  <div class="main">

    <h1>Groups</h1>
    <div class="col-lg-6">
      <?php echo output_message($message, $alert_type); ?>
      <form action="" method="post" class="form-horizontal">
        <p>Add a new group</p>
        <div class="form-group">
          <label class="control-label col-md-4 input-sm">Group Name: </label>
          <div class="col-md-8">
            <input type="text" name="group_name" value="<?php echo $group_name ?>" class="form-control input-sm" required>
          </div>
        </div>

        <div class="form-group">
          <div class="col-md-4"></div>
          <div class="col-md-8">
            <input type="submit" name="submit" value="Save" class="btn btn-primary btn-sm">
          </div>
        </div>
      </form>

    </div>

    <dov class="col-lg-6">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>S/N</th>
            <th>Group Name</th>
          </tr>
        </thead>
        <tbody>

        <?php
          $groups = Group::find_all();
          $count = 1;
          foreach($groups AS $group) {
            echo "<tr>
                    <td>{$count}</td>
                    <td>{$group->group_name}</td>
                  </tr>";
            $count++;
          }
        ?>
        </tbody>
      </table>
    </dov>
  </div>
<?php include_layout_template("footer.php"); ?>