<?php include_once "../includes/initialize.php"; ?>
<?php
  include_layout_template("admin_header.php","Customers");
  include_layout_template("admin_sidebar.php");
?>
  <div class="main">

    <h1>Dashboard</h1>


    <div class="clearfix"></div>

  </div>

<?php include_layout_template("footer.php"); ?>