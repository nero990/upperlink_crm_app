<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/styles.css">

  <link rel="stylesheet" href="css/jquery-ui.min.css">
  <link rel="stylesheet" href="css/jquery-ui.structure.min.css">
  <link rel="stylesheet" href="css/jquery-ui.theme.min.css">

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>
  <script src="js/jquery_validate/jquery.validate.min.js"></script>
  <script src="js/jquery_validate/additional-methods.min.js"></script>

  <title>Upperlink CRM Campaign Manager</title>

</head>
<body>
<div class="wrapper">
  <div class="header">
    <p>UPPERLINK CRM Campaign Manager</p>
  </div>
