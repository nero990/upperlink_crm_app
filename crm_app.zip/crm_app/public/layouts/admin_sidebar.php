<ul class="nav">
  <li><a href="index.php">Dashboard</a></li>
  <li><a href="customers.php">Customers</a></li>
  <li><a href="groups.php">Manage Groups</a></li>
  <li><a href="new_campaign.php">Campaign Manager</a>
    <ul class="subNav">
      <li><a href="new_campaign.php">New Campaign</a></li>
      <li><a href="campaigns.php">List Campaigns</a></li>
    </ul>
  </li>
  <li><a href="#">Logout</a></li>
</ul>