<?php include_once "../includes/initialize.php"; ?>

<?php Campaign::launch(); ?>

<?php
  include_layout_template("admin_header.php","Customers");
  include_layout_template("admin_sidebar.php");
?>
  <div class="main">

    <h1>Campaign List</h1>
    <div class="col-lg-12">
      <?php echo output_message($message, $alert_type); ?>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>S/N</th>
            <th>Campaign Title</th>
            <th>Created on</th>
            <th>Scheduled at</th>
            <th>Campaign Status</th>
            <th>Target Groups</th>
          </tr>
        </thead>
        <tbody>
        <?php
          $count = 1;
          $campaigns = Campaign::find_all();

          foreach($campaigns AS $campaign) {
            $group_campaigns = GroupCampaign::fetch(NULL,$campaign->id);
            $count_gc = count($group_campaigns);

            if($campaign->status == 0) {
              $status = "Proposed";
            } else { $status = "Launched"; }
            echo "<tbody>
                    <tr>
                      <td>{$count}</td>
                      <td>{$campaign->title}</td>
                      <td>{$campaign->created_at}</td>
                      <td>{$campaign->scheduled_at}</td>
                      <td>{$status}</td>
                      <td>";

            $i = 1;
            foreach($group_campaigns as $group_campaign) {
              $group = Group::find_by_id($group_campaign->group_id);

              echo "{$group->group_name}";
              if($i < $count_gc){ echo ", "; }
              $i++;
            }

            echo "</td>
                </tr>
              </tbody>";

            $count++;
          }
        ?>
        </tbody>
      </table>
    </div>

  </div>

<?php include_layout_template("footer.php"); ?>