<?php
	header("Location: public");
	exit;
?>