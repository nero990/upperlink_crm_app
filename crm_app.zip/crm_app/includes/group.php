<?php
  /*
    If it's going to need the database, then it's probaly smart to require it before we start.
  */
  require_once(LIB_PATH.DS."database.php");

  class Group extends DatabaseObject {

    protected static $table_name = "groups";
    protected static $db_fields = array('id', 'group_name');
    public $id;
    public $group_name;


  }
?>