<?php
  /*
    If it's going to need the database, then it's probably smart to require it before we start.
  */
  require_once(LIB_PATH.DS."database.php");

  class GroupCampaign extends DatabaseObject {

    protected static $table_name = "groups_campaigns";
    protected static $db_fields = array('id', 'group_id', 'campaign_id');
    public $id;
    public $group_id;
    public $group_ids;
    public $campaign_id;

    public $group_name;


    public static function fetch($group_id = NULL, $campaign_id = NULL) {

      $sql = "SELECT *  FROM " . static::$table_name . " AS gc ";
      $sql .= "JOIN groups AS g
                ON g.id = gc.group_id ";
      if(!is_null($group_id) && is_null($campaign_id)){
        $sql .= "WHERE gc.group_id = '{$group_id}'";
      } elseif(is_null($group_id) && !is_null($campaign_id)){
        $sql .= "WHERE gc.campaign_id = '{$campaign_id}'";
      }

      return static::find_by_sql($sql);
    }

    public function save() {
      global $database;

      $group_count = count($this->group_ids);
      $i = 1;

      $sql = "INSERT INTO " . static::$table_name;
      $sql .= "(group_id, campaign_id) VALUES ";

      foreach($this->group_ids AS $group_id) {
        $sql .= "('{$group_id}', {$this->campaign_id})";
        if($i < $group_count) {
          $sql .= ", ";
        }
        $i++;
      }

      return $database->query($sql);
    }

  }
?>