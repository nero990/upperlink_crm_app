<?php
  /*
    If it's going to need the database, then it's probably smart to require it before we start.
  */
  require_once(LIB_PATH.DS."database.php");

  class Campaign extends DatabaseObject {

    protected static $table_name = "campaigns";
    protected static $db_fields = array('id', 'title', 'body', 'created_at', 'scheduled_at', 'status');
    public $id;
    public $title;
    public $body;
    public $created_at;
    public $scheduled_at;
    public $status;
    public $groups;

    public $email;

    public static function make($title, $body, $scheduled_at, $groups) {
      if(!empty($title)  && !empty($body) && !empty($scheduled_at)) {
        $campaign = new Campaign();
        $campaign->title = $title;
        $campaign->body = $body;
        $campaign->created_at = date("Y-m-d H:i:s");
        $campaign->scheduled_at = $scheduled_at;
        $campaign->status = 0;
        $campaign->groups = $groups;

        return $campaign;
      } else {
        return FALSE;
      }
    }

    public function save() {
      if(isset($this->id)){
        $this->update();
      } else {
        $this->create();
      }

      if(!empty($this->groups)){
        $group_campaign = new GroupCampaign();
        $group_campaign->group_ids = $this->groups;
        $group_campaign->campaign_id = $this->id;
        return $group_campaign->save();
      } else {
        return false;
      }

    }

    public static function launch() {
      global $database;

      $sql = "SELECT * FROM " . static::$table_name . " AS camp ";
      $sql .= "JOIN groups_campaigns AS gc
                ON gc.campaign_id = camp.id ";
      $sql .= "JOIN groups AS g
                ON g.id = gc.group_id ";
      $sql .= "JOIN customers AS cus
                ON cus.group_id = g.id ";
      $sql .= "WHERE scheduled_at <= now()";

      $database->query($sql);
      while($result = $database->fetch_assoc()){

        $email = $result['email'];
        $to_name = $result['first_name'] . " ". $result['last_name'];
        $title = $result['title'];
        $body = $result['body'];

        // sending campaigns
        $mail = new PHPMailer();
        $mail->FromName = "CRM";
        $mail->From = "noreply@crm.com";
        $mail->AddAddress($email, $to_name);
        $mail->Subject = $title;
        $mail->Body = $body;

        $mail->Send();
      }
    }

  }
?>