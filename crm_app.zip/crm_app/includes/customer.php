<?php
  /*
    If it's going to need the database, then it's probably smart to require it before we start.
  */
  require_once(LIB_PATH.DS."database.php");

  class Customer extends DatabaseObject {

    protected static $table_name = "customers";
    protected static $db_fields = array('id', 'first_name', 'middle_name', 'last_name', 'email', 'group_id');
    public $id;
    public $first_name;
    public $middle_name;
    public $last_name;
    public $email;
    public $group_id;


    public static function make($first_name, $middle_name, $last_name, $email, $group_id) {
      if(!empty($first_name)  && !empty($last_name) && !empty($email) && !empty($group_id) ) {
        $customer = new Customer();
        $customer->first_name = $first_name;
        $customer->middle_name = $middle_name;
        $customer->last_name = $last_name;
        $customer->email = $email;
        $customer->group_id = (int)$group_id;

        return $customer;
      } else {
        return FALSE;
      }
    }


    public function full_name() {
      if(isset($this->first_name) && isset($this->last_name)) {
        return $this->first_name . " " . $this->last_name;
      } else {
        return "";
      }
    }

  }
?>